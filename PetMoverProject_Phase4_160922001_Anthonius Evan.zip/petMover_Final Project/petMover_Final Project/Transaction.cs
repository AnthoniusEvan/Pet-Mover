﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DbSalesPurchasing;
using System.Transactions;
namespace petMover_Final_Project
{
    public class Transaction
    {
        #region Data Members
        Branch branch;
        int id;
        DateTime transactionDate;
        Client client;
        Staff createdBy;
        ServiceType service;
        string destinationAddress;
        City destinationCity;
        DateTime expectedArrival;
        List<TransactionDetail> details;
        #endregion

        #region Properties
        public Branch Branch { get => branch; set => branch = value; }
        public int Id { get => id; set => id = value; }
        public DateTime TransactionDate { get => transactionDate; set => transactionDate = value; }
        public Client Client { get => client; set => client = value; }
        public Staff CreatedBy { get => createdBy; set => createdBy = value; }
        public ServiceType Service { get => service; set => service = value; }
        public string DestinationAddress { get => destinationAddress; set => destinationAddress = value; }
        public City DestinationCity { get => destinationCity; set => destinationCity = value; }
        public DateTime ExpectedArrival { get => expectedArrival; set => expectedArrival = value; }
        internal List<TransactionDetail> Details { get => details; set => details = value; }
        #endregion

        #region Constructors
        public Transaction(Branch branch, int id)
        {
            Branch = branch;
            Id = id;
            Details = new List<TransactionDetail>();
        }
        public Transaction(Branch branch, int id, DateTime transactionDate, Client client, Staff staff, ServiceType service, string address, City city, DateTime expectedArrival)
        {
            Branch = branch;
            Id = id;
            TransactionDate = transactionDate;
            Client = client;
            CreatedBy = staff;
            Service = service;
            DestinationAddress = address;
            DestinationCity = city;
            ExpectedArrival = expectedArrival;
            Details = new List<TransactionDetail>();
        }
        #endregion

        #region Methods
        public static List<Transaction> Get(string searchCriteria, string criteriaValue)
        {
            string sql = "SELECT t.BranchId, t.Id, t.TransactionDateDate, t.ClientId, t.CreatedBy, t.ServiceTypeId, t.DestinationAddress, t.DestinationCity, t.ExpectedArrival, b.Name, c.Name, s.Name, st.Name, ci.Name FROM transaction t INNER JOIN branch b ON t.BranchId = b.Id INNER JOIN client c ON t.ClientId = c.Id INNER JOIN staff s ON t.CreatedBy = s.Id INNER JOIN servicetype st ON t.ServiceTypeId = st.Id INNER JOIN city ci ON t.DestinationCity = ci.Id";
            if (searchCriteria == "any")
            {
                sql += " WHERE t.Id LIKE '%" + criteriaValue + "%' OR b.Name LIKE '%" + criteriaValue + "%' OR c.Name LIKE '%" + criteriaValue + "%' OR s.Name LIKE '%" + criteriaValue + "%' OR st.Name LIKE '%" + criteriaValue + "%' OR ci.Name LIKE '%" + criteriaValue + "%'";
            }
            else if (searchCriteria == "Id")
            {
                string[] code = criteriaValue.Split();
                sql += " WHERE t.BranchId = '" + code[0] + "' AND t.Id = '" + code[1] + "'";
            }
            else if (searchCriteria == "branchdate")
            {
                string[] code = criteriaValue.Split(';');
                sql += " WHERE t.BranchId = '" + code[0] + "' AND t.TransactionDateDate = '" + code[1] + "'";
            }
            else if (searchCriteria == "branch")
            {
                sql += " WHERE t.BranchId = '" + criteriaValue + "'";
            }
            else if (searchCriteria == "date")
            {
                sql += " WHERE t.TransactionDateDate = '" + criteriaValue + "'";
            }
            else if (searchCriteria == "client")
            {
                sql += " WHERE t.ClientId = '" + criteriaValue + "'";
            }
            else if (searchCriteria == "city")
            {
                sql += " WHERE t.DestinationCity = '" + criteriaValue + "'";
            }

            MySql.Data.MySqlClient.MySqlDataReader results = dbConnection.ExecuteQuery(sql);

            List<Transaction> list = new List<Transaction>();
            while (results.Read() == true)
            {
                Branch b = new Branch(results.GetInt32(0), results.GetString(9));
                City ci = new City(results.GetInt32(7), results.GetString(13));
                Client c = new Client(results.GetInt32(3), results.GetString(10));
                Staff s = new Staff(results.GetString(4), results.GetString(11));
                ServiceType st = new ServiceType(results.GetInt32(5), results.GetString(12));
                Transaction t = new Transaction(b, results.GetInt32(1), results.GetDateTime(2), c, s, st, results.GetString(6), ci, results.GetDateTime(8));
                list.Add(t);
            }
            return list;
        }

        public static int Add(Transaction newRecord)
        {
            using (TransactionScope transcope = new TransactionScope())
            {
                try
                {
                    dbConnection con = new dbConnection();
                    string sql = string.Format("INSERT INTO transaction(BranchId, Id, TransactionDateDate, ClientId, CreatedBy, ServiceTypeId, DestinationAddress, DestinationCity, ExpectedArrival) VALUE('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", newRecord.Branch.Id, newRecord.Id, newRecord.TransactionDate.ToString("yyyy-MM-dd"), newRecord.Client.Id, newRecord.CreatedBy.Id, newRecord.Service.Id, newRecord.DestinationAddress, newRecord.DestinationCity.Id, newRecord.ExpectedArrival.ToString("yyyy-MM-dd"));

                    dbConnection.ExecuteNonQuery(sql, con);

                    foreach (TransactionDetail t in newRecord.Details)
                    {
                        string PetTypeId = t.PetType.Id.ToString(), CageId = t.Cage.Id.ToString(), TreatmentId = t.Treatment.Id.ToString();
                        if (t.PetType == null) PetTypeId = "NULL";
                        if (t.Cage == null) CageId = "NULL";
                        if (t.Treatment == null) TreatmentId = "NULL";

                        sql = string.Format("INSERT INTO transactiondetail(BranchId, TransactionId, PetTypeId, CageId, TreatmentId, Description, Qty, Price VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}')", t.Branch.Id, newRecord.Id, PetTypeId, CageId, TreatmentId, t.Description, t.Qty, t.Price);
                        dbConnection.ExecuteNonQuery(sql, con);
                    }

                    transcope.Complete();
                }
                catch (Exception ex)
                {
                    transcope.Dispose();
                    throw new Exception(ex.Message);
                }
                return 1;
            }
        }
        public static Transaction GetByCode(string categoryCode)
        {
            List<Transaction> results = Transaction.Get("Id", categoryCode);
            return results[0];
        }

        public static int Edit(Transaction editRecord)
        {
            string sql = string.Format("UPDATE transaction SET TransactionDateDate = '{0}', ClientId = '{1}', CreatedBy = '{2}', ServiceTypeId = '{3}', DestinationAddress = '{4}', DestinationCity = '{5}', ExpectedArrival = '{6}' WHERE BranchId = '{7}' AND Id = '{8}'", editRecord.TransactionDate.ToString("yyyy-MM-dd"), editRecord.Client.Id, editRecord.CreatedBy.Id, editRecord.Service.Id, editRecord.DestinationAddress,editRecord.DestinationCity.Id,editRecord.ExpectedArrival.ToString("yyyy-MM-dd"),editRecord.Branch.Id,editRecord.Id);

            return dbConnection.ExecuteNonQuery(sql);
        }

        public static int Delete(Transaction deleteRecord)
        {
            string sql = "DELETE FROM transaction WHERE BranchId = '" + deleteRecord.Branch.Id + " AND Id = '" + deleteRecord.Id +"';";

            return dbConnection.ExecuteNonQuery(sql);
        }
        public void AddDetail(TransactionDetail td)
        {
            Details.Add(td);
        }

        public static void Print(string searchCriteria, string criteriaValue, string fileName, Font fontType)
        {
            List<Transaction> transactions = Get(searchCriteria, criteriaValue);

            StreamWriter f = new StreamWriter(fileName);
            foreach (Transaction t in transactions)
            {
                f.WriteLine("");
                f.WriteLine("Pet Mover Company");
                f.WriteLine("Raya Kalirungkut Surabaya");
                f.WriteLine("Phone. (031)-1321349813");
                f.WriteLine("=".PadRight(80, '='));

                f.WriteLine("Order #    : " + t.Id);
                f.WriteLine("Date       : " + t.TransactionDate);
                f.WriteLine("");
                f.WriteLine("Customer   : " + t.Client.Name);
                f.WriteLine("Address    : " + t.Client.Address);
                f.WriteLine("");
                f.WriteLine("Cashier    : " + t.CreatedBy.Name);
                f.WriteLine("=".PadRight(80, '='));

                f.Write("Type".PadRight(30, ' '));
                f.Write("Description".PadLeft(30, ' '));
                f.Write("Price".PadLeft(8, ' '));
                f.Write("Quantity".PadLeft(4, ' '));
                f.Write("Sub Total".PadLeft(8, ' '));
                f.WriteLine("");
                f.WriteLine("=".PadRight(50, '='));

                int grandTotal = 0;
                foreach (TransactionDetail d in t.Details)
                {
                    string productName = "T";
                    productName = productName.Substring(0, Math.Min(30, productName.Length));
                    int qty = d.Qty;
                    int price = d.Price;
                    int subtotal = qty * price;
                    grandTotal += subtotal;

                    f.Write(productName.PadRight(30, ' '));
                    f.Write(qty.ToString().PadLeft(3, ' '));
                    f.Write(price.ToString().PadLeft(7, ' '));
                    f.Write(subtotal.ToString().PadLeft(10, ' '));
                    f.WriteLine("");
                }
                f.WriteLine("=".PadRight(50, '='));
                f.WriteLine("Total: " + grandTotal.ToString("C2"));
                f.WriteLine("=".PadRight(50, '='));
                f.WriteLine("Thank You");
                f.WriteLine("");
            }
            f.Close();
            CustomPrint p = new CustomPrint(fontType, fileName, 20, 10, 10, 10);
            p.SendToPrinter();
        }
        #endregion
    }
}
