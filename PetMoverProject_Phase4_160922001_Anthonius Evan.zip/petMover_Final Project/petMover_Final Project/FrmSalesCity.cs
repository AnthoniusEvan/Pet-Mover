﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace petMover_Final_Project
{
    public partial class FrmSalesCity : Form
    {
        List<Transaction> listOfTransactions = new List<Transaction>();
        public FrmSalesCity()
        {
            InitializeComponent();
        }

        private void FrmSalesCity_Load(object sender, EventArgs e)
        {
            cbCity.DataSource = City.Get("", "");
            cbCity.DisplayMember = "Name";
            cbCity.ValueMember = "Id";
            cbCity_SelectedIndexChanged(sender, e);
        }

        private void cbCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            listOfTransactions = Transaction.Get("city", cbCity.SelectedValue.ToString());

            if (listOfTransactions.Count > 0)
            {
                dgvData.DataSource = listOfTransactions;
                if (!dgvData.Columns.Contains("btnPrint"))
                {
                    DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                    col.HeaderText = "Print";
                    col.Text = "Print";
                    col.Name = "btnPrint";
                    col.UseColumnTextForButtonValue = true;
                    dgvData.Columns.Add(col);
                }
                lblNotFound.Visible = false;
            }
            else
            {
                dgvData.DataSource = null;
                dgvData.Columns.Clear();
            }
        }
    }
}
