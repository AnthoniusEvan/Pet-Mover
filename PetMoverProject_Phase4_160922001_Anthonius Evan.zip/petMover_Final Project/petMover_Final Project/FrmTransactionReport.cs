﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace petMover_Final_Project
{
    public partial class FrmTransactionReport : Form
    {
        List<Transaction> listOfTransactions = new List<Transaction>();
        public FrmTransactionReport()
        {
            InitializeComponent();
        }

        private void dtpLogTime_ValueChanged(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void FrmTransactionReport_Load(object sender, EventArgs e)
        {
            cbBranch.DataSource = Branch.Get("", "");
            cbBranch.DisplayMember = "Name";
            cbBranch.ValueMember = "Id";

            cbBranch.SelectedIndex = 0;
        }
        private void RefreshData()
        {
            string criteria = cbBranch.SelectedValue + ";" + dtpDate.Value.ToString("yyyy-MM-dd");
            if (chbAllBranch.Checked && chbAllPeriod.Checked)
            {
                listOfTransactions = Transaction.Get("", "");
            }
            else if (chbAllPeriod.Checked)
            {
                listOfTransactions = Transaction.Get("branch", cbBranch.SelectedValue.ToString());
            }
            else if (chbAllBranch.Checked)
            {
                listOfTransactions = Transaction.Get("date", dtpDate.Value.ToString("yyyy-MM-dd"));
            }
            else
            {
                listOfTransactions = Transaction.Get("branchdate", criteria);
            }

            if (listOfTransactions.Count > 0)
            {
                dgvData.DataSource = listOfTransactions;
                if (!dgvData.Columns.Contains("btnPrint"))
                {
                    DataGridViewButtonColumn col = new DataGridViewButtonColumn();
                    col.HeaderText = "Print";
                    col.Text = "Print";
                    col.Name = "btnPrint";
                    col.UseColumnTextForButtonValue = true;
                    dgvData.Columns.Add(col);
                }
                lblNotFound.Visible = false;
            }
            else
            {
                dgvData.DataSource = null;
                dgvData.Columns.Clear();

                lblNotFound.Visible = true;
                lblNotFound.Text = string.Format("There are no transactions found at {0} on {1}!", cbBranch.SelectedItem, dtpDate.Value.ToString("D"));
            }
        }
        private void cbBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void chbAllPeriod_CheckedChanged(object sender, EventArgs e)
        {
            if (chbAllPeriod.Checked) dtpDate.Enabled = false;
            else dtpDate.Enabled = true;

            RefreshData();
        }

        private void chbAllBranch_CheckedChanged(object sender, EventArgs e)
        {
            if (chbAllBranch.Checked) cbBranch.Enabled = false;
            else cbBranch.Enabled = true;

            RefreshData();
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvData.Columns["btnPrint"].Index && e.RowIndex >= 0)
            {
                string selectedCode = dgvData.CurrentRow.Cells["Id"].Value.ToString();
                string fileName = "Transaction" + selectedCode + ".pdf";
                Transaction.Print("Id", dgvData.Rows[e.RowIndex].Cells["Id"].Value.ToString(), fileName, new Font("Courier New", 12));

                MessageBox.Show("Transaction has been printed succesfully!");
            }
        }
    }
}
