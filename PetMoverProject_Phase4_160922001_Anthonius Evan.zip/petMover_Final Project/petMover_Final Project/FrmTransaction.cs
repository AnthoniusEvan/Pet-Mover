﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace petMover_Final_Project
{
    public partial class FrmTransaction : Form
    {
        FrmList frmParent;
        int petTypeCount = 0;
        public FrmTransaction()
        {
            InitializeComponent();
        }

        private void FrmTransaction_Load(object sender, EventArgs e)
        {
            frmParent = (FrmList)this.Owner;
            lblCashier.Text = frmParent.activeUser.Id + " - " + frmParent.activeUser.Name;

            if (!frmParent.isEditing)
            {
                txtTransactionId.Text = (Transaction.Get("", "").Count + 1).ToString();
            }

            // Branch
            cbTransactionBranch.DataSource = Branch.Get("", "");
            cbTransactionBranch.DisplayMember = "Name";
            cbTransactionBranch.ValueMember = "Id";

            if (frmParent.selectedBranch != -1)
                cbTransactionBranch.SelectedValue = frmParent.selectedBranch;
            else cbTransactionBranch.SelectedIndex = -1;


            // Service Type
            cbTransactionService.DataSource = ServiceType.Get("", "");
            cbTransactionService.DisplayMember = "Name";
            cbTransactionService.ValueMember = "Id";

            if (frmParent.selectedServiceType != -1)
                cbTransactionService.SelectedValue = frmParent.selectedServiceType;
            else cbTransactionService.SelectedIndex = -1;

            // Client 
            cbTransactionClient.DataSource = Client.Get("", "");
            cbTransactionClient.DisplayMember = "Name";
            cbTransactionClient.ValueMember = "Id";

            if (frmParent.selectedClient != -1)
                cbTransactionClient.SelectedValue = frmParent.selectedClient;
            else cbTransactionClient.SelectedIndex = -1;

            //City
            cbTransactionCity.DataSource = City.Get("", "");
            cbTransactionCity.DisplayMember = "Name";
            cbTransactionCity.ValueMember = "Id";

            if (frmParent.selectedCity != -1)
                cbTransactionCity.SelectedValue = frmParent.selectedCity;
            else cbTransactionCity.SelectedIndex = -1;

            //Type
            foreach(PetType pet in PetType.Get("", ""))
            {
                cbType.Items.Add(pet.Name);
            }
            cbType.Items.Add("Cage");
            cbType.Items.Add("Treatment");
            cbType.SelectedIndex = -1;
            petTypeCount = PetType.Get("", "").Count;
            
            FormatDataGrid();
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTransactionBranch.SelectedIndex != -1 && cbTransactionCity.SelectedIndex != -1 && cbTransactionClient.SelectedIndex != -1 && cbTransactionService.SelectedIndex != -1)
            {
                if (cbType.SelectedIndex < petTypeCount)
                {
                    cbDescription.Visible = false;
                    txtDescription.Visible = true;
                    txtDescription.Text = "Name: ";
                    txtDescription.SelectionStart = txtDescription.Text.Length;
                    txtDescription.Focus();
                }
                else if (cbType.SelectedIndex == petTypeCount)
                {
                    cbDescription.Visible = true;
                    txtDescription.Visible = false;
                    cbDescription.Focus();
                    cbDescription.DataSource = Cage.Get("", "");
                    cbDescription.DisplayMember = "Name";
                    cbDescription.ValueMember = "Id";
                }
                else if (cbType.SelectedIndex == petTypeCount + 1)
                {
                    cbDescription.Visible = true;
                    txtDescription.Visible = false;
                    cbDescription.Focus();
                    cbDescription.DataSource = TreatmentRate.Get("", "");
                }
                else
                {
                    cbDescription.SelectedIndex = -1;
                }
            }
            else
            {
                cbType.SelectedIndex = -1;
                MessageBox.Show("Please fill in the transaction header first!", "Fill out requirements", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void cbDescription_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void txtDescription_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                List<PetType> pet = PetType.Get("Name", cbType.SelectedItem.ToString());
                if (pet.Count > 0)
                {
                    string criteria = Client.Get("Id", cbTransactionClient.SelectedValue.ToString())[0].City.Id + " " + cbTransactionCity.SelectedValue + " " + cbTransactionService.SelectedValue;
                    List<TransportRate> rate = TransportRate.Get("Id", criteria);
                    if (rate.Count < 1)
                    {
                        MessageBox.Show("Unit item not Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        cbType.SelectedIndex = -1;
                        cbDescription.SelectedIndex = -1;
                        txtDescription.Text = "";
                        lblPrice.Text = "";
                        nudQuantity.Value = 0;
                        return;
                    }
                    lblPrice.Text = rate[0].Rate.ToString();
                    nudQuantity.Value = 1;
                    nudQuantity.Focus();
                }
                else
                {
                    MessageBox.Show("Unit item not Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cbType.SelectedIndex = -1;
                    cbDescription.SelectedIndex = -1;
                    txtDescription.Text = "";
                    lblPrice.Text = "";
                    nudQuantity.Value = 0;
                }
            }
        }

        private void cbDescription_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                
                if (cbType.SelectedIndex == petTypeCount)
                {
                    if (cbDescription.SelectedValue==null)
                    {
                        MessageBox.Show("There is no " + cbType.Text + " called " + cbDescription.Text + "!", "Item not found!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }    
                    List<Cage> cage = Cage.Get("Id", cbDescription.SelectedValue.ToString());
                    if (cage.Count > 0)
                    {
                        string criteria = cbDescription.SelectedValue + ";" + cbTransactionService.SelectedValue;
                        List<CageRate> rate = CageRate.Get("Id", criteria);
                        lblPrice.Text = rate[0].Rate.ToString();
                        nudQuantity.Value = 1;
                        nudQuantity.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Unit item not Found!", "Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        cbType.SelectedIndex = -1;
                        cbDescription.SelectedIndex = -1;
                        txtDescription.Text = "";
                        lblPrice.Text = "";
                        nudQuantity.Value = 0;
                    }
                }
                else if (cbType.SelectedIndex == petTypeCount + 1)
                {
                    if (cbDescription.SelectedIndex == -1)
                    {
                        MessageBox.Show("There is no " + cbType.Text + " called " + cbDescription.Text + "!", "Item not found!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    TreatmentRate tr = (TreatmentRate)cbDescription.SelectedItem;
                    if (tr != null)
                    {
                        lblPrice.Text = tr.DailyRate.ToString();
                        nudQuantity.Value = 1;
                        nudQuantity.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Unit item not Found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        cbType.SelectedIndex = -1;
                        cbDescription.SelectedIndex = -1;
                        txtDescription.Text = "";
                        lblPrice.Text = "";
                        nudQuantity.Value = 0;
                    }
                }
            }
        }

        private void nudQuantity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                int subtotal = int.Parse(lblPrice.Text) * (int)nudQuantity.Value;
                int total = int.Parse(lblGrandTotal.Text);
                total += subtotal;
                lblGrandTotal.Text = total.ToString();
                if (txtDescription.Visible)
                dgvProducts.Rows.Add(cbType.Text, txtDescription.Text, lblPrice.Text, nudQuantity.Value, subtotal);
                else
                    dgvProducts.Rows.Add(cbType.Text, cbDescription.Text, lblPrice.Text, nudQuantity.Value, subtotal);

                cbType.SelectedIndex = -1;
                cbDescription.SelectedIndex = -1;
                txtDescription.Text = "";
                lblPrice.Text = "";
                nudQuantity.Value = 0;
                if (dgvProducts.Columns.Contains("btnRemove") != true)
                {
                    DataGridViewButtonColumn colRemove = new DataGridViewButtonColumn();
                    colRemove.HeaderText = "Action";
                    colRemove.Text = "Remove";
                    colRemove.Name = "btnRemove";
                    colRemove.UseColumnTextForButtonValue = true;
                    dgvProducts.Columns.Add(colRemove);
                }

                cbType.Focus();
            }
        }

        private void FormatDataGrid()
        {
            dgvProducts.Columns.Clear();

            dgvProducts.Columns.Add("Type", "Type");
            dgvProducts.Columns.Add("Description", "Description");
            dgvProducts.Columns.Add("Price", "Unit Price");
            dgvProducts.Columns.Add("Quantity", "Quantity");
            dgvProducts.Columns.Add("SubTotal", "Sub Total");

            dgvProducts.Columns["Type"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvProducts.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvProducts.Columns["Price"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvProducts.Columns["Quantity"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dgvProducts.Columns["SubTotal"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;

            dgvProducts.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvProducts.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvProducts.Columns["SubTotal"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvProducts.Columns["Price"].DefaultCellStyle.Format = "#.###";
            dgvProducts.Columns["Quantity"].DefaultCellStyle.Format = "#.###";
            dgvProducts.Columns["SubTotal"].DefaultCellStyle.Format = "#.###";

            dgvProducts.AllowUserToAddRows = false;
            dgvProducts.ReadOnly = true;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Please confirm that you would like to delete the transaction with ID " + txtTransactionId.Text, "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Branch b = new Branch((int)cbTransactionBranch.SelectedValue);
                Transaction t = new Transaction(b, int.Parse(txtTransactionId.Text));
                int affectedRows = Transaction.Delete(t);
                if (affectedRows > 0)
                {
                    MessageBox.Show("Succesfully deleted the transaction with ID " + txtTransactionId.Text + "!");
                    btnCancel_Click(sender, e);
                    frmParent.listCount--;
                }
                else
                {
                    MessageBox.Show("Fail to delete the transacation with ID " + txtTransactionId.Text + ".");
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmParent.btnSearch_Click(sender, e);
            this.Close();
        }

        private void dgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvProducts.Columns["btnRemove"].Index && e.RowIndex >= 0)
            {
                int total = int.Parse(lblGrandTotal.Text);
                total -= (int)dgvProducts.Rows[e.RowIndex].Cells["SubTotal"].Value;
                dgvProducts.Rows.RemoveAt(e.RowIndex);
                lblGrandTotal.Text = total.ToString();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Branch b = new Branch((int)cbTransactionBranch.SelectedValue);
            ServiceType st = new ServiceType((int)cbTransactionService.SelectedValue);
            Client c = new Client((int)cbTransactionClient.SelectedValue);
            Staff s = new Staff(frmParent.activeUser.Id);
            City ci = new City((int)cbTransactionCity.SelectedValue);
            Transaction transaction = new Transaction(b, int.Parse(txtTransactionId.Text), dtpTransactionDate.Value, c, s, st, txtTransactionAddress.Text, ci, dtpTransactionExpectedArrival.Value);
            int rowsAffected;
            if (!frmParent.isEditing)
            {
                for (int i = 0; i < dgvProducts.Rows.Count - 1; i++)
                {
                    DataGridViewRow row = dgvProducts.Rows[i];
                    string productCode = row.Cells[0].Value.ToString();
                    string name = row.Cells[1].Value.ToString();
                    string desc = row.Cells[2].Value.ToString();
                    int price = int.Parse(row.Cells["Price"].Value.ToString());
                    int quantity = int.Parse(row.Cells["Quantity"].Value.ToString());

                    PetType p = null;
                    Cage ca = null;
                    Treatment t = null;
                    if (productCode == "Cage")
                    {
                        ca = new Cage(Cage.Get("Name", name)[0].Id);
                    }
                    else if (productCode == "Treatment")
                    {
                        t = new Treatment(Treatment.Get("Name", name.Split()[1])[0].Id);
                    }
                    else
                    {
                        p = new PetType(Cage.Get("Name", name)[0].Id);
                    }

                    TransactionDetail td = new TransactionDetail(transaction.Id, (Branch)cbTransactionBranch.SelectedItem, p, ca, t, desc, quantity, price);
                    transaction.AddDetail(td);
                }

                Transaction.Add(transaction);
                MessageBox.Show("Succesfully added a new transaction!", "Information");
                frmParent.listCount++;

            }
            else
            {
                rowsAffected = Transaction.Edit(transaction);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Succesfully updated a transaction!", "Information");
                }
                else
                {
                    MessageBox.Show("Failed to update a transaction! UNKNOWN ERROR!");
                }
            }
        }
    }
}
