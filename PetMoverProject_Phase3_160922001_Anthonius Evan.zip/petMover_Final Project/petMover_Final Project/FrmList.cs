﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace petMover_Final_Project
{
    public partial class FrmList : Form
    {
        FrmMain mdiParent;
        string tag;
        public int listCount = 0, selectedCity = -1, selectedCity2 = -1, selectedCage = -1, selectedServiceType = -1, selectedBranch = -1, selectedClient = -1;
        public string selectedStaff = "";
        public bool isEditing = false;
        List<City> listOfCities = new List<City>();
        List<Cage> listOfCages = new List<Cage>();
        List<PetType> listOfPetTypes = new List<PetType>();
        List<ServiceType> listOfServiceTypes = new List<ServiceType>();
        List<Treatment> listOfTreatments = new List<Treatment>();
        List<Branch> listOfBranches = new List<Branch>();
        List<CageRate> listOfCageRates = new List<CageRate>();
        List<Client> listOfClients = new List<Client>();
        List<Staff> listOfStaffs = new List<Staff>();
        List<TransportRate> listOfTransportRates = new List<TransportRate>();
        List<Transaction> listOfTransactions = new List<Transaction>();
        List<TransactionLog> listOfTransactionLogs = new List<TransactionLog>();
        public FrmList()
        {
            InitializeComponent();
        }

        private void FrmList_Load(object sender, EventArgs e)
        {
            mdiParent = (FrmMain)this.MdiParent;
            tag = (string)this.Tag;
            if (tag == "Cities")
            {
                listOfCities = City.Get("", "");
                listCount = listOfCities.Count;
            }
            else if (tag == "Cages")
            {
                listOfCages = Cage.Get("", "");
                listCount = listOfCages.Count;
            }
            else if (tag == "Pet Types")
            {
                listOfPetTypes = PetType.Get("", "");
                listCount = listOfPetTypes.Count;
            }
            else if (tag == "Service Types")
            {
                listOfServiceTypes = ServiceType.Get("", "");
                listCount = listOfServiceTypes.Count;
            }
            else if (tag == "Treatments")
            {
                listOfTreatments = Treatment.Get("", "");
                listCount = listOfTreatments.Count;
            }
            else if (tag == "Branches")
            {
                listOfBranches = Branch.Get("", "");
                listCount = listOfBranches.Count;
            }
            else if (tag == "Cage Rates")
            {
                listOfCageRates = CageRate.Get("", "");
                listCount = listOfCageRates.Count;
            }
            else if (tag == "Clients")
            {
                listOfClients = Client.Get("", "");
                listCount = listOfClients.Count;
            }
            else if (tag == "Staffs")
            {
                listOfStaffs = Staff.Get("", "");
                listCount = listOfStaffs.Count;
            }
            else if (tag == "Transport Rates")
            {
                listOfTransportRates = TransportRate.Get("", "");
                listCount = listOfTransportRates.Count;
            }
            else if (tag == "Transactions")
            {
                listOfTransactions = Transaction.Get("", "");
                listCount = listOfTransactions.Count;
            }
            else if (tag.Split()[1] == "Logs")
            {
                string criteria = tag.Split()[2] + " " + tag.Split()[3];
                listOfTransactionLogs = TransactionLog.Get("any", criteria);
                listCount = listOfTransactionLogs.Count;

                this.Height = Height + lblTransactionInfo.Height;

                lblTransactionInfo.Visible = true;
                lblTransactionInfo.Top = pnlTitle.Bottom + 10;
                lblTransactionInfo.Text = "Transaction ID: " + tag.Split()[3] + "\nBranch: " + Branch.Get("Id", tag.Split()[2])[0].Name;
                pnlSearch.Top = lblTransactionInfo.Bottom + 10;
                btnAdd.Top = lblTransactionInfo.Bottom + 10;
                btnViewAll.Top = lblTransactionInfo.Bottom + 10;
                dgvData.Top = pnlSearch.Bottom + 15;
            }

            RefreshData();
        }
        private void RefreshData()
        {
            bool allowedEdit = true;
            if (listCount > 0)
            {
                if (tag == "Cities") dgvData.DataSource = listOfCities;
                else if (tag == "Cages") dgvData.DataSource = listOfCages;
                else if (tag == "Pet Types") dgvData.DataSource = listOfPetTypes;
                else if (tag == "Service Types") dgvData.DataSource = listOfServiceTypes;
                else if (tag == "Treatments") dgvData.DataSource = listOfTreatments;
                else if (tag == "Branches") dgvData.DataSource = listOfBranches;
                else if (tag == "Cage Rates") dgvData.DataSource = listOfCageRates;
                else if (tag == "Clients") dgvData.DataSource = listOfClients;
                else if (tag == "Staffs") dgvData.DataSource = listOfStaffs;
                else if (tag == "Transport Rates") dgvData.DataSource = listOfTransportRates;
                else if (tag == "Transactions") dgvData.DataSource = listOfTransactions;
                else if (tag.Split()[1] == "Logs")
                {
                    dgvData.DataSource = listOfTransactionLogs;
                    dgvData.Columns["Branch"].Visible = false;
                    dgvData.Columns["Id"].Visible = false;
                    allowedEdit = false;
                }

                if (!dgvData.Columns.Contains("btnEdit") && allowedEdit)
                {
                    DataGridViewButtonColumn colEdit = new DataGridViewButtonColumn();
                    colEdit.HeaderText = "Edit Data";
                    colEdit.Text = "Edit";
                    colEdit.Name = "btnEdit";
                    colEdit.UseColumnTextForButtonValue = true;
                    dgvData.Columns.Add(colEdit);
                }

                if (tag == "Transactions" && !dgvData.Columns.Contains("btnViewLogs"))
                {
                    DataGridViewButtonColumn colLogs = new DataGridViewButtonColumn();
                    colLogs.HeaderText = "View Logs";
                    colLogs.Text = "View";
                    colLogs.Name = "btnViewLogs";
                    colLogs.UseColumnTextForButtonValue = true;
                    dgvData.Columns.Insert(0, colLogs);
                }
            }
            else
            {
                dgvData.DataSource = null;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            isEditing = false;
            FrmDetails f = new FrmDetails();
            f.Owner = this;
            f.lblTitle.Text = "ADD NEW " + tag.ToUpper();
            f.Text = "Add New " + tag;
            f.Tag = tag;
            if (tag == "Treatments" || tag == "Pet Types" || tag == "Service Types")
            {     
                f.pnlIdName.Visible = true;
                f.pnlIdName.Controls["txtId"].Text = "" + (listCount + 1);
                //f.pnlIdName.Controls["txtName"].Text = "";
                f.pnlIdName.Controls["txtId"].Enabled = true;
                f.pnlIdName.Controls["txtName"].Select();
            }
            else if (tag == "Cages")
            {
                f.pnlCage.Visible = true;
                //f.pnlCage.Controls["txtCageId"].Text = "";
                f.pnlCage.Controls["txtCageId"].Text = "" + (listCount + 1);
                f.pnlCage.Controls["txtCageId"].Enabled = true;
                f.pnlCage.Controls["txtCageName"].Select();
            }
            else if (tag == "Cities")
            {
                f.pnlCity.Visible = true;
                f.pnlCity.Controls["txtCityId"].Enabled = true;
                f.pnlCity.Controls["txtCityId"].Text = (listCount + 1).ToString();
                f.pnlCity.Controls["txtCityName"].Select();
            }
            else if (tag == "Branches")
            {
                f.pnlBranch.Visible = true;
                f.pnlBranch.Controls["txtBranchId"].Enabled = true;
                f.pnlBranch.Controls["txtBranchId"].Text = (listCount + 1).ToString();
                f.pnlBranch.Controls["txtBranchName"].Select();
            }
            else if (tag == "Cage Rates")
            {
                f.pnlCageRate.Visible = true;
                f.pnlCageRate.Controls["cbCage"].Enabled = true;
                f.pnlCageRate.Controls["cbServiceType"].Enabled = true;
                f.pnlCageRate.Controls["txtCageRate"].Select();
            }
            else if (tag == "Clients")
            {
                f.pnlClient.Visible = true;
                f.pnlClient.Controls["txtClientId"].Enabled = true;
                f.pnlClient.Controls["txtClientId"].Text = (listCount + 1).ToString();
                f.pnlClient.Controls["txtClientName"].Select();
            }
            else if (tag == "Staffs")
            {
                f.pnlStaff.Visible = true;
                f.pnlStaff.Controls["txtStaffId"].Enabled = true;
                f.pnlStaff.Controls["txtStaffId"].Text = (listCount + 1).ToString();
                f.pnlStaff.Controls["txtStaffName"].Select();
            }
            else if (tag == "Transport Rates")
            {
                f.pnlTransportRate.Visible = true;
                //f.pnlTransportRate.Controls["txtStaffId"].Enabled = true;
                //f.pnlTransportRate.Controls["txtStaffId"].Text = (listCount + 1).ToString();
                f.pnlTransportRate.Controls["txtTRate"].Select();
            }
            else if (tag == "Transactions")
            {
                f.pnlTransaction.Visible = true;
                f.pnlTransaction.Controls["txtTransactionId"].Text = (listCount + 1).ToString();
            }
            else if (tag.Split()[1] == "Logs")
            {
                f.pnlTransactionLog.Visible = true;
                f.lblTitle.Text = "ADD NEW " + tag.Split()[0].ToUpper() + " " +tag.Split()[1].ToUpper();
                f.Text = "Add New " + tag.Split()[0] + " " + tag.Split()[1];
                f.Tag = tag.Split()[1] +" "+ tag.Split()[2] +" "+ tag.Split()[3];
            }
            f.ShowDialog();
        }

        public void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "") btnViewAll.Visible = true;

            if (tag.Split().Count() > 1 && tag.Split()[1] == "Logs")
            {
                if (txtSearch.Text == "")
                {
                    string criteria = tag.Split()[2] + " " + tag.Split()[3];
                    listOfTransactionLogs = TransactionLog.Get("any", criteria);
                }
                else
                {
                    SearchData(txtSearch.Text);
                }
            }
            else SearchData(txtSearch.Text);

            RefreshData();
        }
        private void SearchData(string searchValue)
        {
            if (tag == "Cities") listOfCities = City.Get("any", searchValue);
            else if (tag == "Cages") listOfCages = Cage.Get("any", searchValue);
            else if (tag == "Pet Types") listOfPetTypes = PetType.Get("any", searchValue);
            else if (tag == "Service Types") listOfServiceTypes = ServiceType.Get("any", searchValue);
            else if (tag == "Treatments") listOfTreatments = Treatment.Get("any", searchValue);
            else if (tag == "Branches") listOfBranches = Branch.Get("any", searchValue);
            else if (tag == "Cage Rates") listOfCageRates = CageRate.Get("any", searchValue);
            else if (tag == "Clients") listOfClients = Client.Get("any", searchValue);
            else if (tag == "Staffs") listOfStaffs = Staff.Get("any", searchValue);
            else if (tag == "Transport Rates") listOfTransportRates = TransportRate.Get("any", searchValue);
            else if (tag == "Transactions") listOfTransactions = Transaction.Get("any", searchValue);
            else if (tag.Split()[1] == "Logs") 
            {
                searchValue = tag.Split()[2] + " " + tag.Split()[3] + " " + searchValue;
                listOfTransactionLogs = TransactionLog.Get("search", searchValue);
            }
        }

        private void pnlBgBtnSearch_MouseEnter(object sender, EventArgs e)
        {
            pnlBgBtnSearch.BackColor = Color.Orange;
        }

        private void pnlBgBtnSearch_MouseLeave(object sender, EventArgs e)
        {
            pnlBgBtnSearch.BackColor = Color.Coral;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvData_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }

        private void btnSearch_MouseEnter(object sender, EventArgs e)
        {
            pnlBgBtnSearch.BackColor = Color.Orange;
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvData.Columns["btnEdit"] != null && e.ColumnIndex == dgvData.Columns["btnEdit"].Index && e.RowIndex!=-1)
            {
                string selectedCode="";
                if (tag!="Cage Rates" && tag!="Transport Rates" && tag != "Transactions")
                    selectedCode = dgvData.CurrentRow.Cells["Id"].Value.ToString();
                isEditing = true;
                FrmDetails f = new FrmDetails();
                f.Owner = this;
                f.lblTitle.Text = "EDIT " + tag.ToUpper();
                f.Text = "Edit " + tag;
                f.Tag = tag;
                f.btnDelete.Visible = true;

                if (tag == "Cities")
                {
                    City city = City.GetByCode(selectedCode);

                    if (city != null)
                    {
                        f.pnlCity.Visible = true;
                        f.pnlCity.Controls["txtCityId"].Enabled = false;

                        f.pnlCity.Controls["txtCityId"].Text = city.Id.ToString();
                        f.pnlCity.Controls["txtCityName"].Text = city.Name;
                        f.pnlCity.Controls["txtProvince"].Text = city.Province;
                        f.pnlCity.Controls["txtCityName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Cages")
                {
                    Cage cage = Cage.GetByCode(selectedCode);

                    if (cage != null)
                    {
                        f.pnlCage.Visible = true;
                        f.pnlCage.Controls["txtCageId"].Enabled = false;

                        f.pnlCage.Controls["txtCageId"].Text = cage.Id.ToString();
                        f.pnlCage.Controls["txtCageName"].Text = cage.Name;
                        f.pnlCage.Controls["txtDimensions"].Text = cage.Dimensions;
                        f.pnlCage.Controls["txtCageName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Pet Types")
                {
                    PetType petType = PetType.GetByCode(selectedCode);

                    if (petType != null)
                    {
                        f.pnlIdName.Visible = true;
                        f.pnlIdName.Controls["txtId"].Enabled = false;

                        f.pnlIdName.Controls["txtId"].Text = petType.Id.ToString();
                        f.pnlIdName.Controls["txtName"].Text = petType.Name;
                        f.pnlIdName.Controls["txtName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Service Types")
                {
                    ServiceType serviceType = ServiceType.GetByCode(selectedCode);

                    if (serviceType != null)
                    {
                        f.pnlIdName.Visible = true;
                        f.pnlIdName.Controls["txtId"].Enabled = false;

                        f.pnlIdName.Controls["txtId"].Text = serviceType.Id.ToString();
                        f.pnlIdName.Controls["txtName"].Text = serviceType.Name;
                        f.pnlIdName.Controls["txtName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Treatments")
                {
                    Treatment treatment = Treatment.GetByCode(selectedCode);

                    if (treatment != null)
                    {
                        f.pnlIdName.Visible = true;
                        f.pnlIdName.Controls["txtId"].Enabled = false;

                        f.pnlIdName.Controls["txtId"].Text = treatment.Id.ToString();
                        f.pnlIdName.Controls["txtName"].Text = treatment.Name;
                        f.pnlIdName.Controls["txtName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Branches")
                {
                    Branch branch = Branch.GetByCode(selectedCode);

                    if (branch != null)
                    {
                        selectedCity = branch.City.Id;

                        f.pnlBranch.Visible = true;
                        f.pnlBranch.Controls["txtBranchId"].Enabled = false;

                        f.pnlBranch.Controls["txtBranchId"].Text = branch.Id.ToString();
                        f.pnlBranch.Controls["txtBranchName"].Text = branch.Name;
                        f.pnlBranch.Controls["txtAddress"].Text = branch.Address;
                        f.pnlBranch.Controls["txtPhoneNumber"].Text = branch.PhoneNumber;
                        f.pnlBranch.Controls["txtBranchName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Cage Rates")
                {
                    selectedCode = dgvData.CurrentRow.Cells["Cage"].Value.ToString();
                    string selectedCode2 = dgvData.CurrentRow.Cells["ServiceType"].Value.ToString();
                    // Not reliable if there is multiple cage/service type with the same name
                    foreach (CageRate c in listOfCageRates)
                    {
                        if (c.Cage.Name == selectedCode && c.ServiceType.Name == selectedCode2)
                        {
                            selectedCode = c.Cage.Id + " " + c.ServiceType.Id;
                            break;
                        }
                    }
                    CageRate cageRate = CageRate.GetByCode(selectedCode);

                    if (cageRate != null)
                    {
                        selectedCage = cageRate.Cage.Id;
                        selectedServiceType = cageRate.ServiceType.Id;

                        f.pnlCageRate.Visible = true;
                        f.pnlCageRate.Controls["cbCage"].Enabled = false;
                        f.pnlCageRate.Controls["cbServiceType"].Enabled = false;
                        f.pnlCageRate.Controls["txtCageRate"].Text = cageRate.Rate.ToString();
                        f.pnlCageRate.Controls["txtCageRate"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Clients")
                {
                    Client client = Client.GetByCode(selectedCode);

                    if (client != null)
                    {
                        selectedCity = client.City.Id;

                        f.pnlClient.Visible = true;
                        f.pnlClient.Controls["txtClientId"].Enabled = false;

                        f.pnlClient.Controls["txtClientId"].Text = client.Id.ToString();
                        f.pnlClient.Controls["txtClientName"].Text = client.Name;
                        f.pnlClient.Controls["txtClientAddress"].Text = client.Address;
                        f.pnlClient.Controls["txtClientPhoneNumber"].Text = client.PhoneNumber;
                        f.pnlClient.Controls["txtClientName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Staffs")
                {
                    Staff staff = Staff.GetByCode(selectedCode);

                    if (staff != null)
                    {
                        selectedBranch = staff.Branch.Id;

                        f.pnlStaff.Visible = true;
                        f.pnlStaff.Controls["txtStaffId"].Enabled = false;

                        f.pnlStaff.Controls["txtStaffId"].Text = staff.Id.ToString();
                        f.pnlStaff.Controls["txtStaffName"].Text = staff.Name;
                        f.pnlStaff.Controls["txtStaffName"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Transport Rates")
                {
                    selectedCode = dgvData.CurrentRow.Cells["CityOrigin"].Value.ToString();
                    string selectedCode2 = dgvData.CurrentRow.Cells["CityDestination"].Value.ToString();
                    string selectedCode3 = dgvData.CurrentRow.Cells["ServiceType"].Value.ToString();
                    foreach (TransportRate c in listOfTransportRates)
                    {
                        if (c.CityOrigin.Name == selectedCode && c.CityDestination.Name == selectedCode2 && c.ServiceType.Name == selectedCode3)
                        {
                            selectedCode = c.CityOrigin.Id + " " + c.CityDestination.Id + " " + c.ServiceType.Id;
                            break;
                        }
                    }
                    TransportRate transportRate = TransportRate.GetByCode(selectedCode);

                    if (transportRate != null)
                    {
                        selectedCity = transportRate.CityOrigin.Id;
                        selectedCity2 = transportRate.CityDestination.Id;
                        selectedServiceType = transportRate.ServiceType.Id;

                        f.pnlTransportRate.Visible = true;
                        f.pnlTransportRate.Controls["cbCityOrigin"].Enabled = false;
                        f.pnlTransportRate.Controls["cbCityDestination"].Enabled = false;
                        f.pnlTransportRate.Controls["cbTRServiceType"].Enabled = false;
                        f.pnlTransportRate.Controls["txtTRate"].Text = transportRate.Rate.ToString();
                        f.pnlTransportRate.Controls["txtTRate"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
                else if (tag == "Transactions")
                {
                    selectedCode = dgvData.CurrentRow.Cells["Id"].Value.ToString();
                    string selectedCode2 = dgvData.CurrentRow.Cells["Branch"].Value.ToString();
                    // Not reliable if there is multiple cage/service type with the same name
                    foreach (Transaction c in listOfTransactions)
                    {
                        if (c.Id.ToString() == selectedCode && c.Branch.Name == selectedCode2)
                        {
                            selectedCode = c.Id + " " + c.Branch.Id;
                            break;
                        }
                    }
                    Transaction transaction = Transaction.GetByCode(selectedCode);

                    if (transaction != null)
                    {
                        selectedBranch = transaction.Branch.Id;
                        selectedServiceType = transaction.Service.Id;
                        selectedClient = transaction.Client.Id;
                        selectedStaff = transaction.CreatedBy.Id;
                        selectedCity = transaction.DestinationCity.Id;
                        f.pnlTransaction.Visible = true;
                        f.pnlTransaction.Controls["cbTransactionBranch"].Enabled = false;
                        f.pnlTransaction.Controls["txtTransactionId"].Enabled = false;
                        f.dtpTransactionDate.Value = transaction.TransactionDate;
                        f.pnlTransaction.Controls["txtTransactionAddress"].Text = transaction.DestinationAddress;
                        f.pnlTransaction.Controls["txtTransactionAddress"].Select();
                        f.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Ooops, something went wrong!");
                    }
                }
            }
            else if (dgvData.Columns["btnViewLogs"] != null && e.ColumnIndex == dgvData.Columns["btnViewLogs"].Index && e.RowIndex != -1)
            {
                mdiParent.title = "Transaction Logs";
                int branchId = Branch.Get("Name", dgvData.Rows[e.RowIndex].Cells["Branch"].Value.ToString())[0].Id;
                int transactionId = (int)dgvData.Rows[e.RowIndex].Cells["Id"].Value;
                mdiParent.transactionId = branchId + " " + transactionId;
                mdiParent.OpenMdiChildForm();
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            btnViewAll.Visible = false;
            txtSearch.Text = "";
            btnSearch_Click(sender, e);
            RefreshData();
        }
    }
}
