﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DbSalesPurchasing;
namespace petMover_Final_Project
{
    public class Transaction
    {
        #region Data Members
        Branch branch;
        int id;
        DateTime transactionDate;
        Client client;
        Staff createdBy;
        ServiceType service;
        string destinationAddress;
        City destinationCity;
        DateTime expectedArrival;
        #endregion

        #region Properties
        public Branch Branch { get => branch; set => branch = value; }
        public int Id { get => id; set => id = value; }
        public DateTime TransactionDate { get => transactionDate; set => transactionDate = value; }
        public Client Client { get => client; set => client = value; }
        public Staff CreatedBy { get => createdBy; set => createdBy = value; }
        public ServiceType Service { get => service; set => service = value; }
        public string DestinationAddress { get => destinationAddress; set => destinationAddress = value; }
        public City DestinationCity { get => destinationCity; set => destinationCity = value; }
        public DateTime ExpectedArrival { get => expectedArrival; set => expectedArrival = value; }
        #endregion

        #region Constructors
        public Transaction(Branch branch, int id, DateTime transactionDate, Client client, Staff staff, ServiceType service, string address, City city, DateTime expectedArrival)
        {
            Branch = branch;
            Id = id;
            TransactionDate = transactionDate;
            Client = client;
            CreatedBy = staff;
            Service = service;
            DestinationAddress = address;
            DestinationCity = city;
            ExpectedArrival = expectedArrival;
        }
        #endregion

        #region Methods
        public static List<Transaction> Get(string searchCriteria, string criteriaValue)
        {
            string sql = "SELECT t.BranchId, t.Id, t.TransactionDateDate, t.ClientId, t.CreatedBy, t.ServiceTypeId, t.DestinationAddress, t.DestinationCity, t.ExpectedArrival, b.Name, c.Name, s.Name, st.Name, ci.Name FROM transaction t INNER JOIN branch b ON t.BranchId = b.Id INNER JOIN client c ON t.ClientId = c.Id INNER JOIN staff s ON t.CreatedBy = s.Id INNER JOIN servicetype st ON t.ServiceTypeId = st.Id INNER JOIN city ci ON t.DestinationCity = ci.Id";
            if (searchCriteria == "any")
            {
                sql += " WHERE t.Id LIKE '%" + criteriaValue + "%' OR b.Name LIKE '%" + criteriaValue + "%' OR c.Name LIKE '%" + criteriaValue + "%' OR s.Name LIKE '%" + criteriaValue + "%' OR st.Name LIKE '%" + criteriaValue + "%' OR ci.Name LIKE '%" + criteriaValue + "%'";
            }
            else if (searchCriteria == "Id")
            {
                string[] code = criteriaValue.Split();
                sql += " WHERE t.BranchId = '" + code[0] + "' AND t.Id = '" + code[1] + "'";
            }

            MySql.Data.MySqlClient.MySqlDataReader results = dbConnection.ExecuteQuery(sql);

            List<Transaction> list = new List<Transaction>();
            while (results.Read() == true)
            {
                Branch b = new Branch(results.GetInt32(0), results.GetString(9));
                City ci = new City(results.GetInt32(7), results.GetString(13));
                Client c = new Client(results.GetInt32(3), results.GetString(10));
                Staff s = new Staff(results.GetString(4), results.GetString(11));
                ServiceType st = new ServiceType(results.GetInt32(5), results.GetString(12));
                Transaction t = new Transaction(b, results.GetInt32(1), results.GetDateTime(2), c, s, st, results.GetString(6), ci, results.GetDateTime(8));
                list.Add(t);
            }
            return list;
        }

        public static int Add(Transaction newRecord)
        {
            string sql = string.Format("INSERT INTO transaction(BranchId, Id, TransactionDateDate, ClientId, CreatedBy, ServiceTypeId, DestinationAddress, DestinationCity, ExpectedArrival) VALUE('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')", newRecord.Branch.Id, newRecord.Id, newRecord.TransactionDate.ToString("yyyy-MM-dd"), newRecord.Client.Id, newRecord.CreatedBy.Id, newRecord.Service.Id, newRecord.DestinationAddress, newRecord.DestinationCity.Id, newRecord.ExpectedArrival.ToString("yyyy-MM-dd"));

            return dbConnection.ExecuteNonQuery(sql);

        }
        public static Transaction GetByCode(string categoryCode)
        {
            List<Transaction> results = Transaction.Get("Id", categoryCode);
            return results[0];
        }

        public static int Edit(Transaction editRecord)
        {
            string sql = string.Format("UPDATE transaction SET TransactionDateDate = '{0}', ClientId = '{1}', CreatedBy = '{2}', ServiceTypeId = '{3}', DestinationAddress = '{4}', DestinationCity = '{5}', ExpectedArrival = '{6}' WHERE BranchId = '{7}' AND Id = '{8}'", editRecord.TransactionDate.ToString("yyyy-MM-dd"), editRecord.Client.Id, editRecord.CreatedBy.Id, editRecord.Service.Id, editRecord.DestinationAddress,editRecord.DestinationCity.Id,editRecord.ExpectedArrival.ToString("yyyy-MM-dd"),editRecord.Branch.Id,editRecord.Id);

            return dbConnection.ExecuteNonQuery(sql);
        }

        public static int Delete(Transaction deleteRecord)
        {
            string sql = "DELETE FROM transaction WHERE BranchId = '" + deleteRecord.Branch.Id + " AND Id = '" + deleteRecord.Id +"';";

            return dbConnection.ExecuteNonQuery(sql);
        }

        #endregion
    }
}
